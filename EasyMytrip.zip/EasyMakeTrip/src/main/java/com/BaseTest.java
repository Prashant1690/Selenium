package main.java.com;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseTest{
	public static WebDriver driver;
	public static Properties properties = new Properties();
	
	static final String chrome_path ="G:\\Program Files\\Selenium Lib\\chromedriver_win32\\chromedriver.exe";
	static final String ff_path ="G:\\Program Files\\Selenium Lib\\geckodriver.exe";
	static FileInputStream fip; 
	static ChromeOptions options;
	public JavascriptExecutor js;
	
	public BaseTest(){
		try {
			fip = new FileInputStream("G:\\eclipse-workspace\\EasyMakeTrip\\src\\Config.properties");
			properties.load(fip);
			}
			catch(FileNotFoundException e) {
				e.printStackTrace();
			}catch(IOException e) {
				e.printStackTrace();
		}			
	}
		
	protected static void initialize() {
		String browserName = properties.getProperty("browser");
		if(driver == null) {
			if(browserName.equals("Chrome"))
			{
				System.setProperty("webdriver.chrome.driver",properties.getProperty("chrome_path"));
				setChromePref();
				driver = new ChromeDriver(options);				
			 }
			 else if(browserName.equals("Firefox")) {
				 System.setProperty("webdriver.gecko.driver",properties.getProperty("ff_path"));
				 driver = new FirefoxDriver();			}
		}
		
		
	//	driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get(properties.getProperty("url"));
		System.out.println(driver.getTitle());
		driver.manage().timeouts().pageLoadTimeout(Long.parseLong(properties.getProperty("PageTimeOut", "30")), TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Long.parseLong(properties.getProperty("ImplicitWait", "10")), TimeUnit.SECONDS);		
	}
	
	static void setChromePref() {
		
		Map<String, Object> prefs = new HashMap<String,Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		
		options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);				
	}
	
	
	public void borderElement(WebElement element) {
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].style.border='3px solid red'", element);
		
	}
	
	protected static void driverClose()	{
		if(driver!= null)
			driver.quit();
		
	}

}

