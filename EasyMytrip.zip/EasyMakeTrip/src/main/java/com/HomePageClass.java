package main.java.com;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePageClass extends BaseTest{
	BaseTest base;
	
	@FindBy(xpath = "//*[@id= 'FromSector_show']")
	static WebElement fromField;
	
	@FindBy(xpath = "//div//*[@ id='Editbox13_show']")
	static WebElement toField;
	
	@FindBy(xpath = "//*[@id='fromautoFill']//ul//li")
	static List<WebElement> dropDownFrom;
	
	@FindBy(xpath = "//*[@id='toautoFill']//ul//li")
	static List<WebElement> dropDownTo;
	
	
	@FindBy(xpath = "//*[@id='ddate']")
	static WebElement dateField;
	
	@FindBy(xpath = "//*[@class = 'box']")
	static WebElement calenderPopUp;
	
	@FindBy(xpath = "//*[@class='month2']")
	static WebElement month;
	
	@FindBy(xpath = "//*[@class= 'bor-d51']//li[@class = 'active-date']")
	static WebElement date;
	
	String valMonth, valDate; 
	WebDriverWait wait;
		
	public HomePageClass() {
	    super();
	    
	    //PageFactory.initElements(driver, HomePageClass.class);
	}
	
	@SuppressWarnings("unchecked")
	public String selectSource(String source) throws InterruptedException {
		new BaseTest().borderElement(fromField);
		fromField.click();
		//Thread.sleep(3000);
		fromField.sendKeys(source);
		new BaseTest().borderElement(dropDownFrom.get(0));
		String val = dropDownFrom.get(0).getText();
		dropDownFrom.get(0).click();		
		return val;		
	}
		
	public String selectDest(String dest) throws InterruptedException {		
		new BaseTest().borderElement(toField);
		toField.click();
		Thread.sleep(1000);
		toField.sendKeys(dest);
		Thread.sleep(1000);
		new BaseTest().borderElement(dropDownTo.get(0));
		String val = dropDownTo.get(0).getText();
		dropDownTo.get(0).click();
		return val;
	}
	
	public void pickDate() {
		try{			
			wait.until(ExpectedConditions.visibilityOf(dateField));
			new BaseTest().borderElement(dateField);
			dateField.click();			
			wait.until(ExpectedConditions.visibilityOf(calenderPopUp));		
			new BaseTest().borderElement(calenderPopUp);
			Boolean flag = calenderPopUp.isDisplayed();
			new BaseTest().borderElement(month);
			new BaseTest().borderElement(date);
			if(flag == true) {
				System.out.println("Calender poped up");
				valMonth= month.getText();
				valDate= date.getText(); 
				Thread.sleep(3000);
			}
			else
				System.out.println("Calender didn't pop up");		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
