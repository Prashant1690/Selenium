package test.java.com;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.com.BaseTest;
import main.java.com.HomePageClass;

public class HomePageTest extends BaseTest {

	HomePageClass homePage;
	String source = "Delhi";
	String dest = "Pune";
			
	
	@BeforeClass
	public void setup(){
		BaseTest.initialize();
		homePage = PageFactory.initElements(driver, HomePageClass.class);
	}
	
	@Test(priority =1)
	void getPageTitle() throws InterruptedException {
		Assert.assertTrue(driver.getTitle().contains("EaseMyTrip.com"));
		System.out.println("Browser Opened successfully with title"+ driver.getTitle());
		Thread.sleep(2000);
		
	}
	
	@Test(priority = 2)
	void  setroute() throws InterruptedException {
		String sourceVal =  homePage.selectSource(this.source);
		sourceVal=extract(sourceVal);
		Assert.assertEquals(sourceVal,this.source);
		String destVal= homePage.selectDest(this.dest);
		destVal=extract(destVal);
		Assert.assertEquals(destVal,this.dest);
		System.out.println("Source: "+sourceVal+" and"+"destination:" + destVal);
		
	}
	
	private String extract(String sourceVal) {
		//To extract the destination name from the selected dropdown
		StringBuffer extractedSource = new StringBuffer();
		for(int i=0 ,j=1;i<sourceVal.length();i++,j++) {
			if (sourceVal.charAt(i)!='(')
				extractedSource.append(sourceVal.charAt(i));
			else
				break;
		}
		
		return String.valueOf(extractedSource);
	}

	@Test(priority = 3)
	void selectdate()throws InterruptedException  {
		if(homePage == null)
			System.out.println("null");
		else
			System.out.println(homePage.toString());
		
		//homePage.pickDate();
	}
	
	@AfterClass
	void tearDown() {		
		BaseTest.driverClose();
	}
	
	
	
	
}
